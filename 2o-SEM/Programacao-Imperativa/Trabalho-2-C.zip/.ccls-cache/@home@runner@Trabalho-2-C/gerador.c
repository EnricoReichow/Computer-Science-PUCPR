// gerador.c
//#include "prototipo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura para os dados
typedef struct {
  char nomePiloto[50];
  char escuderia[50];
} Dado;

// Estrutura do nó da lista encadeada
typedef struct Node {
  Dado data;
  struct Node *next;
} Node;

// Função para inserir elemento na lista encadeada
Node *inserirElemento(Node *lista, Dado novoDado) {
  Node *novoNode = (Node *)malloc(sizeof(Node));
  if (novoNode == NULL) {
    fprintf(stderr, "Erro ao alocar memória para novo elemento.\n");
    exit(EXIT_FAILURE);
  }

  novoNode->data = novoDado;
  novoNode->next = NULL;

  if (lista == NULL ||
      strcmp(novoDado.nomePiloto, lista->data.nomePiloto) < 0) {
    novoNode->next = lista;
    return novoNode;
  }

  Node *atual = lista;
  while (atual->next != NULL &&
         strcmp(novoDado.nomePiloto, atual->next->data.nomePiloto) > 0) {
    atual = atual->next;
  }

  novoNode->next = atual->next;
  atual->next = novoNode;

  return lista;
}

// Função para ler dados do arquivo texto
Node *lerArquivoTexto(char *nomeArquivo) {
  FILE *arquivo = fopen(nomeArquivo, "r");
  if (arquivo == NULL) {
    fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
    exit(EXIT_FAILURE);
  }

  Node *lista = NULL;
  Dado temp;

  while (fscanf(arquivo, "%s %s", temp.nomePiloto, temp.escuderia) == 2) {
    lista = inserirElemento(lista, temp);
  }

  fclose(arquivo);
  return lista;
}

// Função para gravar dados em um arquivo binário
void gravarArquivoBinario(char *nomeArquivo, Node *lista) {
  FILE *arquivo = fopen(nomeArquivo, "wb");
  if (arquivo == NULL) {
    fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
    exit(EXIT_FAILURE);
  }

  Node *atual = lista;
  while (atual != NULL) {
    if (fwrite(&(atual->data), sizeof(Dado), 1, arquivo) != 1) {
      fprintf(stderr, "Erro ao escrever no arquivo binário.\n");
      exit(EXIT_FAILURE);
    }
    atual = atual->next;
  }

  fclose(arquivo);
}

// Função para liberar a memória alocada para a lista
void liberarMemoriaRecursiva(Node *lista) {
    if (lista == NULL) {
        return; // Caso base: a lista está vazia, nada a liberar
    }

    Node *proximo = lista->next;
    free(lista);

    // Chamada recursiva para o próximo nó na lista
    liberarMemoriaRecursiva(proximo);
}

int main(int argc, char *argv[]) {
  if (argc != 2) {
    printf("Uso: %s <arquivo_texto>\n", argv[0]);
    return 1;
  }

  char *nomeArquivoTexto = argv[1];

  // Ler dados do arquivo texto e criar lista encadeada
  Node *lista = lerArquivoTexto(nomeArquivoTexto);

  // Gravar dados no arquivo binário
  gravarArquivoBinario("dados.bin", lista);

  // Liberar a memória alocada para a lista
  liberarMemoriaRecursiva(lista);

  return 0;
}
