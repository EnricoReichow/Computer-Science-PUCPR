// gerenciador.h

#ifndef GERENCIADOR_H
#define GERENCIADOR_H

// Estrutura para os dados
typedef struct {
    char nomePiloto[50];
    char escuderia[50];
} Dado;

// Estrutura do nó da lista encadeada
typedef struct Node {
    Dado data;
    struct Node* next;
} Node;

// Funções para manipulação da lista encadeada
Node* inserirElemento(Node* lista, Dado novoDado);
Node* lerArquivoTexto(char* nomeArquivo);
void gravarArquivoBinario(char* nomeArquivo, Node* lista);
void liberarMemoria(Node* lista);

#endif // GERENCIADOR_H
