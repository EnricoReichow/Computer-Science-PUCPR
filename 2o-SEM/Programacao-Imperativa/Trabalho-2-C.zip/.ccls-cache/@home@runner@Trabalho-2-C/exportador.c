// exportador.c
//#include "prototipo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura para os dados
typedef struct {
    char nomePiloto[50];
    char escuderia[50];
} Dado;

// Estrutura do nó da lista encadeada
typedef struct Node {
    Dado data;
    struct Node* next;
} Node;

// Função para inserir elemento na lista encadeada
Node* inserirElemento(Node* lista, Dado novoDado) {
    Node* novoNode = (Node*)malloc(sizeof(Node));
    if (novoNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória para novo elemento.\n");
        exit(EXIT_FAILURE);
    }

    novoNode->data = novoDado;
    novoNode->next = NULL;

    if (lista == NULL || strcmp(novoDado.nomePiloto, lista->data.nomePiloto) < 0) {
        novoNode->next = lista;
        return novoNode;
    }

    Node* atual = lista;
    while (atual->next != NULL && strcmp(novoDado.nomePiloto, atual->next->data.nomePiloto) > 0) {
        atual = atual->next;
    }

    novoNode->next = atual->next;
    atual->next = novoNode;

    return lista;
}

// Função para ler dados do arquivo binário
Node* lerArquivoBinario(char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "rb");
    if (arquivo == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
        exit(EXIT_FAILURE);
    }

    Node* lista = NULL;
    Dado temp;

    while (fread(&temp, sizeof(Dado), 1, arquivo) == 1) {
        lista = inserirElemento(lista, temp);
    }

    fclose(arquivo);
    return lista;
}

// Função para exportar dados para o arquivo texto
void exportarArquivoTexto(char* nomeArquivo, Node* lista) {
    FILE* arquivo = fopen(nomeArquivo, "w");
    if (arquivo == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
        exit(EXIT_FAILURE);
    }

    Node* atual = lista;
    while (atual != NULL) {
        fprintf(arquivo, "%s %s\n", atual->data.nomePiloto, atual->data.escuderia);
        atual = atual->next;
    }

    fclose(arquivo);
}

// Função para liberar a memória alocada para a lista
void liberarMemoria(Node* lista) {
    Node* atual = lista;
    while (atual != NULL) {
        Node* proximo = atual->next;
        free(atual);
        atual = proximo;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Uso: %s <arquivo_binario>\n", argv[0]);
        return 1;
    }

    char* nomeArquivoBinario = argv[1];

    // Ler dados do arquivo binário e criar lista encadeada
    Node* lista = lerArquivoBinario(nomeArquivoBinario);

    // Exportar dados para o arquivo texto
    exportarArquivoTexto("dados_exportados.txt", lista);

    // Liberar a memória alocada para a lista
    liberarMemoria(lista);

    return 0;
}
