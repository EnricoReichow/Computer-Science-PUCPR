// editor.c
//#include "prototipo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura para os dados
typedef struct {
    char nomePiloto[50];
    char escuderia[50];
} Dado;

// Estrutura do nó da lista encadeada
typedef struct Node {
    Dado data;
    struct Node* next;
} Node;

// Função para inserir elemento na lista encadeada
Node* inserirElemento(Node* lista, Dado novoDado) {
    Node* novoNode = (Node*)malloc(sizeof(Node));
    if (novoNode == NULL) {
        fprintf(stderr, "Erro ao alocar memória para novo elemento.\n");
        exit(EXIT_FAILURE);
    }

    novoNode->data = novoDado;
    novoNode->next = NULL;

    if (lista == NULL || strcmp(novoDado.nomePiloto, lista->data.nomePiloto) < 0) {
        novoNode->next = lista;
        return novoNode;
    }

    Node* atual = lista;
    while (atual->next != NULL && strcmp(novoDado.nomePiloto, atual->next->data.nomePiloto) > 0) {
        atual = atual->next;
    }

    novoNode->next = atual->next;
    atual->next = novoNode;

    return lista;
}

// Função para ler dados do arquivo binário
Node* lerArquivoBinario(char* nomeArquivo) {
    FILE* arquivo = fopen(nomeArquivo, "rb");
    if (arquivo == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
        exit(EXIT_FAILURE);
    }

    Node* lista = NULL;
    Dado temp;

    while (fread(&temp, sizeof(Dado), 1, arquivo) == 1) {
        lista = inserirElemento(lista, temp);
    }

    fclose(arquivo);
    return lista;
}

// Função para realizar operações sobre os dados
void realizarOperacoes(Node* lista) {
    int opcao;
    do {
        printf("\n1. Inserir novo piloto\n");
        printf("2. Remover piloto\n");
        printf("3. Exibir dados de um piloto\n");
        printf("4. Encerrar\n");
        printf("Escolha a opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
          case 1:
          {
              Dado novoPiloto;
              printf("Digite o nome do piloto (se tiver mais de uma palavra separar por _ ): ");
              scanf("%s", novoPiloto.nomePiloto);
              printf("Digite a escuderia do piloto (se tiver mais de uma palavra separar por _ ): ");
              scanf("%s", novoPiloto.escuderia);

              // Insere o novo piloto na lista
              lista = inserirElemento(lista, novoPiloto);

              printf("Novo piloto inserido com sucesso.\n");
          }
          break;

          case 2:
          {
              char nomeRemover[50];
              printf("Digite o nome do piloto a ser removido (se tiver mais de uma palavra separar por _ ): ");
              scanf("%s", nomeRemover);

              Node* anterior = NULL;
              Node* atual = lista;

              while (atual != NULL && strcmp(nomeRemover, atual->data.nomePiloto) != 0) {
                  anterior = atual;
                  atual = atual->next;
              }

              if (atual != NULL) {
                  // Remove o piloto da lista
                  if (anterior == NULL) {
                      // O piloto a ser removido é o primeiro da lista
                      lista = atual->next;
                  } else {
                      anterior->next = atual->next;
                  }

                  free(atual);
                  printf("Piloto removido com sucesso.\n");
              } else {
                  printf("Piloto não encontrado.\n");
              }
          }
          break;

          
          case 3:
          {
              char nomeExibir[50];
              printf("Digite o nome do piloto a ser exibido (se tiver mais de uma palavra separar por _ ): ");
              scanf("%s", nomeExibir);

              Node* atual = lista;

              while (atual != NULL && strcmp(nomeExibir, atual->data.nomePiloto) != 0) {
                  atual = atual->next;
              }

              if (atual != NULL) {
                  // Exibe os dados do piloto
                  printf("Nome do piloto: %s\n", atual->data.nomePiloto);
                  printf("Escuderia: %s\n", atual->data.escuderia);
              } else {
                  printf("Piloto não encontrado.\n");
              }
          }
          break;

            case 4:
                break;

          
            default:
                printf("Opcao invalida. Tente novamente.\n");
        }
    } while (opcao != 4);
}

// Função para gravar dados atualizados no arquivo binário
void gravarArquivoBinario(char* nomeArquivo, Node* lista) {
    FILE* arquivo = fopen(nomeArquivo, "wb");
    if (arquivo == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo %s\n", nomeArquivo);
        exit(EXIT_FAILURE);
    }

    Node* atual = lista;
    while (atual != NULL) {
        if (fwrite(&(atual->data), sizeof(Dado), 1, arquivo) != 1) {
            fprintf(stderr, "Erro ao escrever no arquivo binário.\n");
            exit(EXIT_FAILURE);
        }
        atual = atual->next;
    }

    fclose(arquivo);
}

// Função para liberar a memória alocada para a lista
void liberarMemoria(Node* lista) {
    Node* atual = lista;
    while (atual != NULL) {
        Node* proximo = atual->next;
        free(atual);
        atual = proximo;
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Uso: %s <arquivo_binario>\n", argv[0]);
        return 1;
    }

    char* nomeArquivoBinario = argv[1];

    // Ler dados do arquivo binário e criar lista encadeada
    Node* lista = lerArquivoBinario(nomeArquivoBinario);

    // Realizar operações sobre os dados
    realizarOperacoes(lista);

    // Gravar dados atualizados no arquivo binário
    gravarArquivoBinario(nomeArquivoBinario, lista);

    // Liberar a memória alocada para a lista
    liberarMemoria(lista);

    return 0;
}